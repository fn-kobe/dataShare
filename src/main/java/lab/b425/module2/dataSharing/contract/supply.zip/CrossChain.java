package lab.b425.module2.dataSharing.contract.supply;

import com.owlike.genson.Genson;
import org.hyperledger.fabric.contract.Context;
import org.hyperledger.fabric.contract.ContractInterface;
import org.hyperledger.fabric.contract.annotation.*;
import org.hyperledger.fabric.shim.ChaincodeException;
import org.hyperledger.fabric.shim.ChaincodeStub;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

@Contract(name = "crossChain", info = @Info(title = "", description = "", version = "", license = @License(), contact = @Contact()))
@Default
public class CrossChain implements ContractInterface {

    private final Genson genson = new Genson();

    private enum CrossChainError {
        ASSET_NOT_FOUND,
        CONTRACT_NOT_FOUND,
        STATE_ERROR,
        KEY_ERROR,
        TIME_PERIOD_ERROR
    }

    @Transaction(intent = Transaction.TYPE.SUBMIT)
    public void newHTLC(final Context ctx,
                        final String assetId,
                        final String sender,
                        final String receiver,
                        final double price,
                        final String timeLock,
                        final String perImage,
                        final String fromChannel,
                        final String targetChannel) {
        ChaincodeStub stub = ctx.getStub();
        List<String> args = new ArrayList<>();
        String lockAccount = sender + assetId;
        //调用合约的方法名
        args.add("changeCarOwner");
        //对应使用合约car，参数1为修改汽车拥有者，参数2为修改拥有者电话
        args.add(lockAccount);
        args.add("");
        try {
            stub.invokeChaincodeWithStringArgs("supplymain", args, targetChannel);
        } catch (Exception e) {
            String errorMessage = String.format("asset %d does not exist", assetId);
            System.out.println(errorMessage);
            throw new ChaincodeException(errorMessage, CrossChainError.ASSET_NOT_FOUND.toString());
        }

        String contractId = sender + assetId;
        String hashLock = EncryptSha256Util.getSha256Str(perImage);
        String state = "1";
        LockContract lockContract = new LockContract(contractId, sender, receiver, fromChannel, targetChannel, assetId, price, timeLock, hashLock, state);
        String lockContractJSON = genson.serialize(lockContract);
        stub.putStringState(contractId,lockContractJSON);
        System.out.println("a new HTLC successfully created.");
    }

    //取出资产的接口
    @Transaction(intent = Transaction.TYPE.SUBMIT)
    public void withDraw(final Context ctx, final String key, final String contractId) {
        ChaincodeStub stub = ctx.getStub();
        //判断合约是否存在
        String HTLC = stub.getStringState(contractId);
        if (HTLC != null && !HTLC.isEmpty()) {
            LockContract contract = genson.deserialize(HTLC, LockContract.class);
            //判断合约状态是否合法
            if (!contract.getState().equals("1")) {
                String errorMessage = String.format("HTLC contract %d state error", contractId);
                System.out.println(errorMessage);
                throw new ChaincodeException(errorMessage, CrossChainError.STATE_ERROR.toString());
            }
            //判断合约是否超时
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Calendar instance = Calendar.getInstance();
            instance.setTime(new Date());
            String cur_time = df.format(instance.getTime());
            if (cur_time.compareTo(contract.getTimeLock()) >= 0) {
                String errorMessage = String.format("HTLC contract %d time period error", contractId);
                System.out.println(errorMessage);
                throw new ChaincodeException(errorMessage, CrossChainError.TIME_PERIOD_ERROR.toString());
            }
            //判断密钥是否正确
            String str = EncryptSha256Util.getSha256Str(key);
            if (!str.equals(contract.getHashLock())) {
                String errorMessage = String.format("HTLC contract %d key error", contractId);
                System.out.println(errorMessage);
                throw new ChaincodeException(errorMessage, CrossChainError.KEY_ERROR.toString());
            }
            //完成验证之后执行取出操作
            List<String> args = new ArrayList<>();
            //调用合约方法,创建出新的资产
            /**
             * 待补充，新建资产如何集成原有资产的信息
             */
            args.add("createCar");
            args.add("");
            stub.invokeChaincodeWithStringArgs("supplymain", args, contract.getTargetChannel());

            //修改合约状态并保存
            contract.setState("2");
            String contractJSON = genson.serialize(contract);
            stub.putStringState(contractId, contractJSON);

        } else {
            String errorMessage = String.format("HTLC contract %d does not exist", contractId);
            System.out.println(errorMessage);
            throw new ChaincodeException(errorMessage, CrossChainError.CONTRACT_NOT_FOUND.toString());
        }
    }

    @Transaction
    public void reFund(final Context ctx, final String contractId) {
        ChaincodeStub stub = ctx.getStub();
        //判断合约是否存在
        String HTLC = stub.getStringState(contractId);
        if (HTLC != null && !HTLC.isEmpty()) {
            LockContract contract = genson.deserialize(HTLC, LockContract.class);
            //判断合约状态是否合法
            if (!contract.getState().equals("1")) {
                String errorMessage = String.format("HTLC contract %d state error", contractId);
                System.out.println(errorMessage);
                throw new ChaincodeException(errorMessage, CrossChainError.STATE_ERROR.toString());
            }
            //判断合约是否仍然有效
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Calendar instance = Calendar.getInstance();
            instance.setTime(new Date());
            String cur_time = df.format(instance.getTime());
            if (cur_time.compareTo(contract.getTimeLock()) < 0) {
                String errorMessage = String.format("HTLC contract %d time period error", contractId);
                System.out.println(errorMessage);
                throw new ChaincodeException(errorMessage, CrossChainError.TIME_PERIOD_ERROR.toString());
            }
            //执行撤回操作
            List<String> args = new ArrayList<>();
            //调用合约方法,撤回原有资产
            args.add("changeCarOwner");
            args.add(contract.getSender());
            args.add("");
            stub.invokeChaincodeWithStringArgs("supplymain", args, contract.getFromChannel());

            //修改合约状态
            contract.setState("3");
            String contractJSON = genson.serialize(contract);
            stub.putStringState(contractId, contractJSON);
        } else {
            String errorMessage = String.format("HTLC contract %d does not exist", contractId);
            System.out.println(errorMessage);
            throw new ChaincodeException(errorMessage, CrossChainError.CONTRACT_NOT_FOUND.toString());
        }
    }

    @Transaction()
    public boolean HTLCExist(final Context ctx, final String contractId) {
        ChaincodeStub stub = ctx.getStub();
        String HTLC = stub.getStringState(contractId);
        return (HTLC != null && !HTLC.isEmpty());
    }

}
