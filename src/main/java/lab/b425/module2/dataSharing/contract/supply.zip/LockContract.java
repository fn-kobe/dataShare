package lab.b425.module2.dataSharing.contract.supply;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import org.hyperledger.fabric.contract.annotation.DataType;
import org.hyperledger.fabric.contract.annotation.Property;

/**
 * <p>
 * 合约类实体
 * </p>
 *
 * @author MFL
 * @since 2022-04-17
 */
@Data
@DataType()
public final class LockContract {

    @Property()
    private String contractId;

    @Property()
    private String sender;

    @Property()
    private String receiver;

    @Property()
    private String fromChannel;

    @Property()
    private String targetChannel;

    @Property()
    private String assetId;

    @Property()
    private Double price;

    @Property()
    private String timeLock;

    @Property()
    private String hashLock;

    @Property()
    private String state;

    public LockContract(@JsonProperty("contractId") final String contractId,
                        @JsonProperty("sender") final String sender,
                        @JsonProperty("receiver") final String receiver,
                        @JsonProperty("fromChannel") final String fromChannel,
                        @JsonProperty("targetChannel") final String targetChannel,
                        @JsonProperty("assetId") final String assetId,
                        @JsonProperty("price") final Double price,
                        @JsonProperty("timeLock") final String timeLock,
                        @JsonProperty("hashLock") final String hashLock,
                        @JsonProperty("state") final String state) {
        this.contractId = contractId;
        this.sender = sender;
        this.receiver = receiver;
        this.fromChannel = fromChannel;
        this.targetChannel = targetChannel;
        this.assetId = assetId;
        this.price = price;
        this.timeLock = timeLock;
        this.hashLock = hashLock;
        this.state = state;
    }
}
